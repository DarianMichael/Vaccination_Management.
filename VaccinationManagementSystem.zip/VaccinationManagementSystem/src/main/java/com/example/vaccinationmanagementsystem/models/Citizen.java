package com.example.vaccinationmanagementsystem.models;

import com.example.vaccinationmanagementsystem.enums.Disease;
import com.example.vaccinationmanagementsystem.enums.Status;
import com.example.vaccinationmanagementsystem.mapper.RepresentationMappable;
import com.example.vaccinationmanagementsystem.marker.BaseEntity;
import com.example.vaccinationmanagementsystem.representation.CitizenRepresentation;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Citizen implements BaseEntity, RepresentationMappable<CitizenRepresentation> {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(unique = true, nullable = false)
    private Long id;
    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private Disease disease;
    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private Status status;
    @Column(nullable = false)
    private LocalDate registrationDate;
    private LocalDate scheduledDate;

    @OneToOne
    private Person person;


    @Transient
    private int priority;

    private String vaccineName;

    public Citizen(Disease disease, Status status, LocalDate registrationDate, LocalDate scheduledDate, Person person, String vaccineName) {
        this.disease = disease;
        this.status = status;
        this.registrationDate = registrationDate;
        this.scheduledDate = scheduledDate;
        this.person = person;
        priority = 0;
        this.vaccineName = vaccineName;
    }

    @Override
    public CitizenRepresentation toRepresentation() {
        return new CitizenRepresentation(id, disease, status, registrationDate, scheduledDate, person.toRepresentation(), vaccineName);
    }
}

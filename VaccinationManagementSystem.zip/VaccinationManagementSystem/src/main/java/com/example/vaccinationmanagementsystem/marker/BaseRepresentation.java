package com.example.vaccinationmanagementsystem.marker;

public interface BaseRepresentation {
}

package com.example.vaccinationmanagementsystem.mapper;

public interface EntityMappable<T> {
    T toEntity();
}

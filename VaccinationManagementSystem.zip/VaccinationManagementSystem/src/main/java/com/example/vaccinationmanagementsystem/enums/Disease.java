package com.example.vaccinationmanagementsystem.enums;

public enum Disease {
    NONE, MID, HIGH
}

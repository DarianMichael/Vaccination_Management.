package com.example.vaccinationmanagementsystem.exception;

public class BaseException extends RuntimeException {
    public BaseException(String msg) {
        super(msg);
    }
}

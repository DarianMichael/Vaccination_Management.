package com.example.vaccinationmanagementsystem.exception;

public class VaccineEntityNotFoundException extends BaseException {
    public VaccineEntityNotFoundException(String s) {
        super(s);
    }
}

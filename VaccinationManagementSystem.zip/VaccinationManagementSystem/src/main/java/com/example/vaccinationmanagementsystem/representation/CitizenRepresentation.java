package com.example.vaccinationmanagementsystem.representation;

import com.example.vaccinationmanagementsystem.enums.Disease;
import com.example.vaccinationmanagementsystem.enums.Status;
import com.example.vaccinationmanagementsystem.mapper.EntityMappable;
import com.example.vaccinationmanagementsystem.marker.BaseRepresentation;
import com.example.vaccinationmanagementsystem.models.Citizen;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CitizenRepresentation implements BaseRepresentation, EntityMappable<Citizen> {
    private Long id;
    @NotNull
    public Disease disease;
    @NotNull
    private Status status;
    private LocalDate registrationDate;
    private LocalDate scheduledDate;
    @Valid
    private PersonRepresentation person;
    private String vaccineName;

    @Override
    public Citizen toEntity() {
        return new Citizen(disease, status, registrationDate, scheduledDate, person.toEntity(), vaccineName);
    }
}

package com.example.vaccinationmanagementsystem.exception;

public class DuplicatedPersonException extends BaseException {
    public DuplicatedPersonException(String msg) {
        super(msg);
    }
}

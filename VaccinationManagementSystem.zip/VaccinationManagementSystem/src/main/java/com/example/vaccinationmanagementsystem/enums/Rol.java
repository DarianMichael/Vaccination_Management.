package com.example.vaccinationmanagementsystem.enums;

public enum Rol {
    ADMIN, CITIZEN
}

package com.example.vaccinationmanagementsystem.mapper;

public interface RepresentationMappable<T> {
    T toRepresentation();
}

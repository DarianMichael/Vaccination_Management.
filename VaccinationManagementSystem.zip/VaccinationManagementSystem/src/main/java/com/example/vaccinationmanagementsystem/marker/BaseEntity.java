package com.example.vaccinationmanagementsystem.marker;

public interface BaseEntity {
}

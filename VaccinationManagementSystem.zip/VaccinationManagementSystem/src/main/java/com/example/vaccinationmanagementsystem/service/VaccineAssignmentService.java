package com.example.vaccinationmanagementsystem.service;

import com.example.vaccinationmanagementsystem.enums.Disease;
import com.example.vaccinationmanagementsystem.enums.Status;
import com.example.vaccinationmanagementsystem.models.*;
import com.example.vaccinationmanagementsystem.repository.*;
import com.example.vaccinationmanagementsystem.representation.GeneralResponseStatus;
import com.example.vaccinationmanagementsystem.representation.VaccinatedLastPeopleCounter;
import com.example.vaccinationmanagementsystem.util.AgeUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class VaccineAssignmentService {
    public static final String MAX_PEOPLE_PER_DAY = "peoplePerDay";
    public static final int INTIAL_COUNTER_VALUE = 0;
    public static final int INCREMENT = 1;
    private ParamRepository paramRepository;
    private VaccineRepository vaccineRepository;
    private AgeRangeRepository ageRangeRepository;
    private AgePriorityRepository agePriorityRepository;
    private DiseasePriorityRepository diseasePriorityRepository;
    private CitizenRepository citizenRepository;

    @Autowired
    public VaccineAssignmentService(ParamRepository paramRepository, VaccineRepository vaccineRepository,
                                    AgeRangeRepository ageRangeRepository, AgePriorityRepository agePriorityRepository,
                                    DiseasePriorityRepository diseasePriorityRepository,
                                    CitizenRepository citizenRepository) {
        this.paramRepository = paramRepository;
        this.vaccineRepository = vaccineRepository;
        this.ageRangeRepository = ageRangeRepository;
        this.agePriorityRepository = agePriorityRepository;
        this.diseasePriorityRepository = diseasePriorityRepository;
        this.citizenRepository = citizenRepository;
    }

    private List<Vaccine> vaccines;
    private List<AgeRange> ageRangeList;
    private List<AgePriority> agePriorities;
    private List<DiseasePriority> diseasePriorities;
    List<Citizen> citizens;
    private int maxPeopleByDay;
    private VaccinatedLastPeopleCounter counter;


    public GeneralResponseStatus makeAssigment() {
        List<Citizen> privileged = new ArrayList<>();
        initValues();
        citizens = retrieveCitizenSortedList();
        for (Citizen citizen : citizens) {
            if (citizen.getStatus() == Status.SCHEDULED) {
                continue;
            }
            processCitizen(citizen).map(vaccine -> {
                int quantity = vaccine.getQuantity();
                if (quantity > 0) {
                    vaccine.setQuantity(quantity - 1);
                    citizen.setStatus(Status.SCHEDULED);
                    citizen.setScheduledDate(computeDateForVaccination());
                    citizen.setVaccineName(vaccine.getName());
                    privileged.add(citizen);
                    citizenRepository.save(citizen);
                }
                return vaccine;
            });
        }
        return new GeneralResponseStatus(privileged);
    }

    private LocalDate computeDateForVaccination() {
        if (counter.getCounter() < maxPeopleByDay) {
            counter.setCounter(counter.getCounter() + INCREMENT);
            return counter.getLastDate();
        }
        counter.setCounter(INTIAL_COUNTER_VALUE);
        counter.setLastDate(counter.getLastDate().plus(INCREMENT, ChronoUnit.DAYS));
        return counter.getLastDate();
    }

    private VaccinatedLastPeopleCounter computeLastVaccinatedPeople() {
        LocalDate lastDate = citizens.stream()
                .map(Citizen::getRegistrationDate)
                .max(Comparator.comparing(localDate -> localDate))
                .get();
        long count = citizens.stream()
                .filter(citizen -> citizen.getRegistrationDate().equals(lastDate))
                .count();
        return new VaccinatedLastPeopleCounter(count, lastDate);
    }

    private Optional<Vaccine> processCitizen(Citizen citizen) {
        int age = AgeUtil.computeAge(citizen.getPerson());
        Long ageId = computeAgeId(citizen);
        return ageRangeList.stream().
                filter(ageRange -> Objects.equals(ageRange.getId(), ageId))
                .findFirst().map(ageRange -> ageRange.getVaccine().stream()
                        .max(Comparator.comparingInt(Vaccine::getQuantity))
                        .get()
                );
    }

    private List<Citizen> retrieveCitizenSortedList() {
        return citizens.stream()
                .peek(citizen -> {
                    Long ageId = computeAgeId(citizen);
                    citizen.setPriority(computeAgePriority(ageId) + computeDiseasePriority(citizen.getDisease()));
                })
                .sorted(Comparator.comparing(Citizen::getRegistrationDate))
                .sorted(Comparator.comparingInt(Citizen::getPriority)).collect(Collectors.toList());
    }

    private void initValues() {
        citizens = citizenRepository.findAll();
        vaccines = vaccineRepository.findAll();
        ageRangeList = ageRangeRepository.findAll();
        diseasePriorities = diseasePriorityRepository.findAll();
        agePriorities = agePriorityRepository.findAll();
        maxPeopleByDay = Integer.parseInt(paramRepository.findParamByName(MAX_PEOPLE_PER_DAY)
                .map(param -> param.getValue())
                .orElse("0"));
        counter = computeLastVaccinatedPeople();

    }

    private int computeDiseasePriority(Disease disease) {
        return diseasePriorities.stream()
                .filter(diseasePriority -> disease == diseasePriority.getDisease())
                .findFirst()
                .map(DiseasePriority::getValue)
                .orElse(0);
    }

    private int computeAgePriority(Long ageId) {
        return agePriorities.stream()
                .filter(agePriority -> Objects.equals(agePriority.getAgeRange().getId(), ageId))
                .findFirst()
                .map(AgePriority::getValue).orElse(0);
    }

    private Long computeAgeId(Citizen citizen) {
        int age = AgeUtil.computeAge(citizen.getPerson());
        return ageRangeList.stream()
                .filter(ageRange -> age >= ageRange.getLowThreshold())
                .filter(ageRange -> age <= ageRange.getHighThreshold())
                .findFirst()
                .map(AgeRange::getId).orElse(0L);
    }

}

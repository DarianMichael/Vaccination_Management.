package com.example.vaccinationmanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VaccinationManagementSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(VaccinationManagementSystemApplication.class, args);
    }

}

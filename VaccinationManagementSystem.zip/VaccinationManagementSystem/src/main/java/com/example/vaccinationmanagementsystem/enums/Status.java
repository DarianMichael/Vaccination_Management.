package com.example.vaccinationmanagementsystem.enums;

public enum Status {
    PENDING, SCHEDULED
}

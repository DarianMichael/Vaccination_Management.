package com.example.vaccinationmanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VaccinationManagementSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
